#!/bin/sh
rm -r build
npm run-script build
