In the clear_test file we assume that when we register a user and then clear the whole dictionary
and then register again another user, that that user has an id of 1.

Also, we assume that in iteration 1 there will not be any deletion/removing of users and channels
so that is why we use the length of the loaded data_store to determine the user and channel id. 
For future iterations we have thought of a algorithm to determine the missing/next user and channel id. 



for the function channels_list_v1 we assume that the auth_user_id will always be a valid type.

For the function channel_messages_v1 we assume that now in iteration 1 there are no messages that is why the end value is -1

